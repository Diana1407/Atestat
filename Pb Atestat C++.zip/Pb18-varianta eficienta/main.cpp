#include <iostream>

using namespace std;

int main()
{
    int n,c[30001]={0},maxi=0;
    cin>>n;
    for(int i=1;i<n;i++)
    {
        for(int j=i;j<=n;j+=i)
            c[j]++;
        if(c[i]>maxi)
            maxi=c[i];
    }
    c[n]++;
    if(c[n]>maxi)
        cout<<"DA";
    else
        cout<<"NU";

    return 0;
}
