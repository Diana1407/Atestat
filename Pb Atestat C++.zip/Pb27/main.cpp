#include <iostream>
#include <fstream>

using namespace std;

ifstream f("mat.in");
ofstream g("mat.out");

int main()
{
    int n,m,l,c,a[101][101];
    f>>n>>m>>l>>c;

    for(int i=1;i<=n;i++)
        for(int j=1;j<=m;j++)
            f>>a[i][j];

    for(int i=l;i<=n-1;i++)
        for(int j=1;j<=m;j++)
            a[i][j]=a[i+1][j];
    n--;
    for(int j=c;j<=m-1;j++)
        for(int i=1;i<=n;i++)
            a[i][j]=a[i][j+1];
    m--;

    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=m;j++)
            g<<a[i][j]<<" ";
        g<<endl;
    }

    return 0;
}
