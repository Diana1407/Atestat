#include <iostream>

using namespace std;

int cmmdc(int a, int b)
{
    while(b)
    {
        int rez=a%b;
        a=b;
        b=rez;
    }
    return a;
}

int main()
{
    /// a/b si c/d
    int a,b,c,d;
    cin>>a>>b>>c>>d;
    int sus=a*d+b*c;
    int jos=b*d;
    int simplifica=cmmdc(sus,jos);
    cout<<sus/simplifica<<" "<<jos/simplifica;
    return 0;
}
