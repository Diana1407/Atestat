#include <iostream>
#include <fstream>

using namespace std;

ifstream f("mat.in");


int main()
{
    int n,a[101][101],sl[101]={0},sc={0},dp=0,ds=0;
    cin>>n;
    for(int i=0;i<n;i++)
        for(int j=0;j<n;j++)
        {
            cin>>a[i][j];
            sl[i]+=a[i][j];
            sj[j]+=a[i][j];
            if(i==j)
                dp+=a[i][j];
            if(i+j=n-1)
                ds+=a[i][j];
        }
    if(dp!=ds)
    {
        cout<<"nu";
        return 0;
    }
    for(int i=0;i<n;i++)
        if(sl[i]!=ds || sc[i]!=ds)
    {
        cout<<"nu";
        return 0;
    }
    cout<<"da";
    return 0;




    return 0;
}
