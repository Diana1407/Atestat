#include <iostream>

using namespace std;

int main()
{
    int n,a[101][101],ok=1;
    cin>>n;
    for(int i=0;i<n;i++)
        for(int j=0;j<n;j++)
            cin>>a[i][j];
    int s=a[0][0];
    for(int i=0;i<n-1;i++)
        for(int j=0;j<n-i;j++)
            if(s%2!=a[i][j]%2)
            {
                ok=0;
                break;
            }

    if(ok==1)
        cout<<"da";
    else
        cout<<"nu";
    return 0;
}
