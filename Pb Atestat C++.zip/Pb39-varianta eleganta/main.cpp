///interclasarea direct din citire
#include <iostream>
#include <fstream>
#include <cstring>

using namespace std;

ifstream f("X.txt");
ifstream ff("Y.txt");

int main()
{
    char x[26], y[26];
    f.getline(x,26);
    ff.getline(y,26);
    int i=1,j=1;
    while(i<7 && j<7)
    {

        if(strcmp(x,y)<0)
        {
            cout<<x<<" ";
            i++;
            f.getline(x,26);
        }
        else
        {
            if(strcmp(x,y)==0)
            {
                cout<<y<<" ";
                i++;
                j++;
                f.getline(x,26);
                ff.getline(y,26);
            }
            else
            {
                cout<<y<<" ";
                j++;
                ff.getline(y,26);

            }
        }
    }
    while(i<=7)
    {
        cout<<x<<" ";
        f.getline(x,26);
            i++;
    }
    while(j<=7)
    {
        cout<<y<<" ";
        ff.getline(y,26);
            j++;

    }

    return 0;
}

