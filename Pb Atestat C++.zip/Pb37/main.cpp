#include <iostream>
#include <fstream>
#include <cstring>

using namespace std;

ifstream f("text.in");

int compar(char x[], char y[])
{
    for(int i=0;i<strlen(x);i++)
        if(x[i]>='A' && x[i]<='Z')
            x[i]+=32;
    for(int i=0;i<strlen(y);i++)
        if(y[i]>='A' && y[i]<='Z')
            y[i]+=32;
    if(strcmp(x,y)>0)
        return 1;
    else
        return 0;
}

int main()
{
    char s[256],d[25][256];
    int k=0;
    f.getline(s,256);
    char *p=strtok(s," ");
    while(p)
    {
        strcpy(d[k++],p);
        p=strtok(NULL," ");
    }
    for(int i=0;i<k;i++)
    {
        for(int j=i+1;j<k;j++)
        {
            if(compar(d[i],d[j])==1)
                swap(d[i],d[j]);
        }
    }
    for(int i=0;i<k;i++)
        cout<<d[i]<<" ";
    return 0;
}
