///SORTARE PRIN SELECTIE DE MINIM
///se putea si prin selectie de maxim
#include <iostream>
#include <fstream>

using namespace std;

ifstream f("sort.in");
ofstream g("sort.out");

int main()
{
    int n,a[51];
    f>>n;
    for(int i=0;i<n;i++)
        f>>a[i];
    for(int i=0;i<n;i++)
    {
        int poz=i;
        for(int j=i+1;j<n;j++)
            if(a[j]<a[poz])
                poz=j;
        swap(a[poz],a[i]);
    }
    for(int i=0;i<n;i++)
        g<<a[i]<<" ";
    return 0;
}
