#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;

ifstream f("pol.in");
ofstream g("pol.out");

int main()
{
    int n,m;
    f>>n>>m;
    double a[50]={0},b[50]={0};
    for(int i=0;i<=n;i++)
        f>>a[i];
    for(int i=0;i<=m;i++)
        f>>b[i];
    if(m>n)
        swap(n,m);
    for(int i=0;i<=n;i++)
        a[i]+=b[i];
    while(a[n]==0 && n>0)
        n--;
    g<<n<<"\n";
    for(int i=0;i<=n;i++)
        g<<fixed<<setprecision(2)<<a[i]<<" ";
    return 0;
}
