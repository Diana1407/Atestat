///SORTARE PRIN NUMARARE
#include <iostream>
#include <fstream>

using namespace std;

ifstream f("sort.in");
ofstream g("sort.out");

int main()
{
    int n,a[100],b[100];
    f>>n;
    for (int i=0;i<n;i++)
        f>>a[i];
    for (int i=0;i<n;i++)
    {
        int nr=0;
        for (int j=0;j<i;j++)
            if (a[j]<a[i])
            nr++;
        for (int j=i+1;j<n;j++)
            if (a[j]<=a[i])
                nr++;
        b[nr]=a[i];
    }
    for (int i=0;i<n;i++)
        g<<b[i]<<" ";
    return 0;
}
