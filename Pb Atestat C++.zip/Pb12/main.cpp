#include <iostream>
#include <fstream>

using namespace std;

ifstream f("cmmdc.in");
ofstream g("cmmdc.out");

int cmmdc(int a, int b)
{
    while(b)
    {
        int r=a%b;
        a=b;
        b=r;
    }
    return a;
}

int main()
{
    int n;
    f>>n;
    int x,y;
    f>>x;
    for(int i=1;i<n;i++)
    {
        f>>y;
        int r=cmmdc(x,y);
        x=r;
    }
    g<<x;
    return 0;
}
