#include <iostream>

using namespace std;

int prim(int x)
{
    if(x<=1 || x>2 && x%2==0)
        return 0;
    for(int d=3; d*d<=x; d+=2)
        if(x%d==0)
            return 0;
    return 1;
}

int main()
{
    int n,a[101][101],s=0;
    cin>>n;
    for(int i=0;i<n;i++)
        for(int j=0;j<n;j++)
            cin>>a[i][j];
    for(int i=0;i<n-1;i++)
        for(int j=i+1;j<n;j++)
            if(prim(a[i][j])==1)
                s+=a[i][j];
    cout<<s;
    return 0;
}
