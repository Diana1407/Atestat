#include <iostream>
#include <fstream>

using namespace std;

ifstream f("sir.in");

void sortare(int n, int a[])
{
    for(int i=0; i<n; i++)
        for(int j=i+1; j<n; j++)
            if(a[i]>a[j])
                swap(a[i],a[j]);
}

int main()
{
    int n,a[51],nr=0;
    f>>n;
    for(int i=0; i<n; i++)
        f>>a[i];
    sortare(n,a);
    int x=1,y=1,i=0;
    while(i<n)
    {
        if(x>a[n-1])
            i=n;
        int t=x;
        if(a[i]==x || a[i]==y || a[i]==x+y)
        {
            nr++;

            x=y;
            y=t+y;
            i++;
        }
        else
        {
            x=y;
            y=t+y;
        }

    }
    cout<<nr;

    return 0;
}

///un nr n este termen fibonacci daca si numai daca 5n^2+4 sau 5n^2-4 este patrat perfect
