///Suma a doua numere mari
#include <iostream>
#include <fstream>
#include <string.h>

using namespace std;

ifstream fin("numere.in");
ofstream g("numere.out");

void fac_sir(int a[])
{
    char s[51];
    int i,j;
    fin.getline(s,51);
    for(i=strlen(s)-1, j=1; i>=0; i--,j++)
        a[j]=s[i]-'0';
    a[0]=j;
}

int main()
{
    int a[52]={0}, b[52]={0}, c[52]={0};
    fac_sir(a);
    fac_sir(b);
    if(a[0]>b[0])
        c[0]=a[0];
    else
        c[0]=b[0];
    for(int i=1;i<=c[0];i++)
    {
        c[i]+=a[i]+b[i];
        if(c[i]>9)
        {
            c[i+1]=1;
            c[i]=c[i]%10;
        }
    }
    if(c[c[0]+1]!=0)
        c[0]++;
    for(int i=c[0]-1;i>=1;i--)
        g<<c[i];
    return 0;
}
