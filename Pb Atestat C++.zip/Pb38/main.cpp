#include <iostream>
#include <fstream>
#include <cstring>

using namespace std;

ifstream f("text.in");

int main()
{
    int k=0;
    char s[256],d[25][256];
    f.getline(s,256);
    char *p=strtok(s," ");
    while(p)
    {
        strcpy(d[k++],p);
        p=strtok(NULL," ");
    }
    for(int i=0;i<k;i++)
    {
        for(int j=i+1;j<k;j++)
        {
            if(strlen(d[i])>strlen(d[j]))
                swap(d[i],d[j]);
        }
    }
    for(int i=0;i<k;i++)
        cout<<d[i]<<"\n";
    return 0;
}
