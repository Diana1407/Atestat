#include <iostream>

using namespace std;

int par(int x)
{
    int s=0;
    while(x)
    {
        s+=x%10;
        x/=10;
    }
    if(s%2==0)
        return 1;
    return 0;
}

int main()
{
    int n,a[101][101],ok=0;
    cin>>n;
    for(int i=0;i<n;i++)
        for(int j=0;j<n;j++)
            cin>>a[i][j];
    for(int i=1;i<n;i++)
        for(int j=n-i;j<n;j++)
            if(par(a[i][j])==1)
            {
                ok=1;
                break;
            }
    if(ok==1)
        cout<<"da";
    else
        cout<<"nu";
    return 0;
}
