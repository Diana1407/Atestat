#include <iostream>
#include <fstream>
#include <cstring>

using namespace std;

ifstream f("X.txt");
ifstream ff("Y.txt");

int main()
{
    char d[8][26],dd[8][26];
    for(int i=0; i<7; i++)
    {
        f.getline(d[i],26);
        ff.getline(dd[i],26);
    }
    int i=0,j=0;
    while(i<7 && j<7)
    {
        if(strcmp(d[i],dd[j])<0)
        {
            cout<<d[i]<<" ";
            i++;
        }
        else
        {
            if(strcmp(d[i],dd[j])==0)
            {
                cout<<dd[j]<<" ";
                i++;
                j++;
            }
            else
            {
                cout<<dd[j]<<" ";
                j++;

            }
        }
    }
    while(i<7)
    {
        cout<<d[i]<<" ";
        i++;
    }
    while(j<7)
    {
        cout<<dd[j]<<" ";
        j++;
    }
    return 0;
}

///alta varianta sa fac interclasarea direct din citire
