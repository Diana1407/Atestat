#include <iostream>
#include <fstream>

using namespace std;

ifstream f("progrsie.in");
ofstream g("progrsie.out");

int main()
{
    int n,a[51];
    f>>n;
    for(int i=0;i<n;i++)
        f>>a[i];
    int r=a[1]-a[0];
    int q=a[1]/a[0];
    int oka=1,okg=1;
    for(int i=1;i<n;i++)
    {
        if(a[i]-a[i-1]!=r)
            oka=0;
        if(a[i]/a[i-1]!=q)
            okg=0;
    }
    if(oka==1)
        g<<"elementele şirului formează o progresie algebrică cu raţia "<<r;
    if(okg==1)
        g<<"elementele şirului formează o progresie geometrică cu raţia "<<q;
    return 0;
}
