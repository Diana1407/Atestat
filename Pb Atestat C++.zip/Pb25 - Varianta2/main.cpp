#include <iostream>
#include <fstream>

using namespace std;

ifstream f("mat1.in");
ofstream g("mat1.out");

int minl[101],maxc[101];

void citire(int &n,int &m,int a[][101])
{
    f>>n>>m;
    for(int i=0;i<n;i++)
    {
        int minim=99999;
        for(int j=0;j<m;j++)
        {
            int maxim=0;
            f>>a[i][j];
            if(a[i][j]<minim)
                minim=a[i][j];
            if(a[i][j]>maxim)
                maxim=a[i][j];
            if(maxim!=0)
                maxc[j]=maxim;
        }
        minl[i]=minim;
    }


}

int main()
{
    int n=0,a[101][101],m=0;
    citire(n,m,a);
    for(int i=0;i<n;i++)
        for(int j=0;j<m;j++)
    {
        if(minl[i]==maxc[j] && a[i][j]==minl[i])
            g<<a[i][j]<<" ";
    }
    return 0;
}
