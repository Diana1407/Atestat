#include <iostream>
#include <fstream>
#include <cstring>

using namespace std;

ifstream f("text.in");

int verif(char x[])
{
    int l=strlen(x);
    for(int i=0;i<l/2;i++)
        if(x[i]!=x[l-i-1])
    {
        return 0;
    }
    return 1;

}

int main()
{
    char s[256];
    f.getline(s,256);
    char *p=strtok(s," ");
    while(p)
    {
        if(verif(p)==1)
            cout<<p<<endl;
        p=strtok(NULL," ");
    }
    return 0;
}
