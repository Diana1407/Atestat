#include <iostream>

using namespace std;

int nrdiv(int x)
{
    int d,nrd=0;
    for(d=1;d*d<x;d++)
        if(x%d==0)
            nrd+=2;
    if(d*d==x)
        nrd++;
    return nrd;
}

int main()
{
    int k;
    cin>>k;
    int d=1;
    while(nrdiv(d)!=k)
    {
        d++;
    }
    cout<<d;
    return 0;
}
