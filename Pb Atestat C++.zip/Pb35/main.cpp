#include <iostream>
#include <fstream>
#include <cstring>

using namespace std;

ifstream f("text.in");
ofstream g("rime.out");

int main()
{
    char s[256],d[25][256];
    int k=0;
    f.getline(s,256);
    char *p=strtok(s," ");
    while(p)
    {
        strcpy(d[k++],p);
        p=strtok(NULL," ");
    }
    for(int i=0; i<k-1; i++)
    {
        int l1=strlen(d[i]);
        if(l1>1)
        {
            for(int j=i+1; j<k; j++)
            {
                int l2=strlen(d[j]);
                if(l2>1)
                {
                    if(d[i][l1-1]==d[j][l2-1] && d[i][l1-2]==d[j][l2-2])
                        g<<d[i]<<" "<<d[j]<<endl;
                }

            }
        }


    }
    return 0;
}
