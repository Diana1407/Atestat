#include <iostream>
#include <fstream>

using namespace std;

ifstream f("exista.in");

int nrdiv(int x)
{
    int nr=0,d;
    for(d=1;d*d<x;d++)
        if(x%d==0)
            nr+=2;
    if(d*d==x)
        nr++;
    return nr;
}

int main()
{
    int n,a[51];
    f>>n;
    for(int i=0;i<n;i++)
        f>>a[i];
    int ok=0;
    for(int i=0; i<n && ok==0; i++)
    {
        if(nrdiv(a[i])==nrdiv(a[i+1]) && nrdiv(a[i])==nrdiv(a[i+2]))
            ok=1;
    }
    if(ok==1)
        cout<<"Da";
    else
        cout<<"Nu";
    return 0;
}
