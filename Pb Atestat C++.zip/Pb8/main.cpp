#include <iostream>
#include <fstream>

using namespace std;

ifstream f("mult.in");

int main()
{
    int n,a[51],ok=1;
    f>>n;
    for(int i=0;i<n;i++)
        f>>a[i];
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n && j!=i;j++)
            if(a[i]==a[j])
            {
                ok=0;
                break;
            }
        if(ok==0)
            break;
    }
    if(ok==1)
        cout<<"da";
    else
        cout<<"nu";
    return 0;
}
