#include <iostream>
#include <string.h>
#include <fstream>

using namespace std;

ifstream f("text.in");
ofstream g("text.out");

int main()
{
    char s[256];
    int a[35]={0};
    f.getline(s,256);
    int l=strlen(s);
    for(int i=0;i<l;i++)
    {
        if(s[i]>='a' && s[i]<='z')
            a[s[i]-'a']++;
        if(s[i]>='A' && s[i]<='Z')
            a[s[i]-'A']++;
    }
    for(int i=0;i<35;i++)
    {
        if(a[i]!=0)
        {
            char p=char(i)+'A';
            g<<p<<" "<<a[i]<<endl;
        }


    }
    return 0;
}
