#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("mat1.in");
ofstream fout("mat1.out");

void citire(int &n,int &m,int a[][101])
{
    fin>>n>>m;
    for(int i=1;i<=n;i++)
        for(int j=1;j<=m;j++)
        fin>>a[i][j];
}

void aflare(int n,int m,int a[][101])
{
    int maxi=0,ok;
    for(int i=1;i<=n;i++)
    {
        maxi=a[i][1];
        for(int j=1;j<=m;j++)
        {
            if(a[i][j]>maxi)
                maxi=a[i][j];
        }
        for(int j=1;j<=m;j++)
        {
            if(a[i][j]==maxi)
            {
                ok=1;
                for(int ii=1;ii<=n;ii++)
                {
                    if(a[ii][j]<a[i][j])
                        ok=0;
                }
                if(ok)
                    fout<<a[i][j]<<" ";
            }
        }
    }
}

int main()
{
    int n=0,a[101][101]={0},m=0;
    citire(n,m,a);
    aflare(n,m,a);
    return 0;
}
///fac un vector de minim pe linie
///unul de maxim pe coloana
///parcurg matricea si vad
