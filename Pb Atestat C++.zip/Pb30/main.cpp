#include <iostream>
#include <cstring>

using namespace std;

int main()
{
    int ap[35]={0}, ok=1;
    char cuv1[256], cuv2[256];
    cin>>cuv1>>cuv2;
    for(int i=0;i<strlen(cuv1);i++)
    {
        if(cuv1[i]>='a' && cuv1[i]<='z')
            ap[cuv1[i]-'a']++;
        if(cuv1[i]>='A' && cuv1[i]<='Z')
            ap[cuv1[i]-'A']++;
    }

    for(int i=0;i<strlen(cuv2);i++)
    {
        if(cuv2[i]>='a' && cuv2[i]<='z')
            ap[cuv2[i]-'a']--;
        if(cuv2[i]>='A' && cuv2[i]<='Z')
            ap[cuv2[i]-'A']--;
    }

    for(int i=0;i<35;i++)
    {
        if(ap[i]!=0)
        {
            ok=0;
            break;
        }
    }
    if(ok==0)
        cout<<"NU";
    else
        cout<<"DA";
    return 0;
}
