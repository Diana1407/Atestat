#include <iostream>
#include <fstream>

using namespace std;

ofstream g("prietene.out");

int prim(int x)
{
    if(x<=1 || x>2 && x%2==0)
        return 0;
    for(int d=3; d*d<=x; d+=2)
        if(x%d==0)
            return 0;
    return 1;
}

int main()
{
    int n;
    cin>>n;
    for(int i=1; i<n; i++)
    {
        if(prim(i)==1)
        {
            if(prim(i+1)==1)
                g<<"("<<i<<","<<i+1<<") ";
            else
                if(prim(i+2)==1)
                    g<<"("<<i<<","<<i+2<<") ";
        }
    }
    return 0;
}
