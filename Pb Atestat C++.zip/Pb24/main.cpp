#include <iostream>
#include <fstream>

using namespace std;

ifstream f1("mat1.in");
ifstream f2("mat2.in");

int main()
{
    int p[101][101]={0};
    int n1,m1,a1[101][101];
    f1>>n1>>m1;
    for(int i=0;i<n1;i++)
        for(int j=0;j<m1;j++)
            f1>>a1[i][j];

    int n2,m2,a2[101][101];
    f2>>n2>>m2;
    for(int i=0;i<n2;i++)
        for(int j=0;j<m2;j++)
            f2>>a2[i][j];

    if(m1!=n2)
        cout<<"Nu se poate calcula produsul";
    else
    {

        for(int i=0;i<n1;i++)
            for(int j=0;j<m2;j++)
                for(int k=0;k<m1;k++)
                    p[i][j]+=a1[i][k]*a2[k][j];

    }
    for(int i=0;i<n1;i++)
    {
        for(int j=0;j<m2;j++)
            cout<<p[i][j]<<" ";
        cout<<endl;
    }

    return 0;
}
