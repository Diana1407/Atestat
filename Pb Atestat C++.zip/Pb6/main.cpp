#include <iostream>
#include <fstream>

using namespace std;

ifstream f("mult.in");
ofstream g("mult.out");

int main()
{
    int n,m,a[51],b[51],c[51],k=0;
    f>>n>>m;
    for(int i=0;i<n;i++)
        f>>a[i];
    for(int i=0;i<m;i++)
        f>>b[i];

    for(int i=0;i<n;i++)
    {
        int ok=1;
        for(int j=0;j<m;j++)
            if(a[i]==b[j])
        {
            ok=0;
            break;
        }
        if(ok==1)
            c[k++]=a[i];
    }


    for(int i=0;i<k;i++)
        g<<c[i]<<" ";


    return 0;
}
