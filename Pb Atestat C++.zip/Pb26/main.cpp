#include <iostream>
#include <fstream>

using namespace std;

int nrdiv(int x)
{
    int nr=0,i;
    for(i=1;i*i<x;i++)
        if(x%i==0)
            nr+=2;
    if(i*i==x)
        nr++;
    return nr;
}

ifstream f("mat.in");

int main()
{
    int n,m,a[101][101],maxi=-1;
    f>>n>>m;
    for(int i=0;i<n;i++)
        for(int j=0;j<m;j++)
            f>>a[i][j];

    for(int i=0;i<n;i++)
        for(int j=0;j<m;j++)
        {
            if(nrdiv(a[i][j])>maxi)
                maxi=nrdiv(a[i][j]);
        }
    for(int i=0;i<n;i++)
        for(int j=0;j<m;j++)
            if(nrdiv(a[i][j])==maxi)
                cout<<a[i][j]<<endl;
    return 0;
}
