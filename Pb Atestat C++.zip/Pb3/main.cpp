#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;

ifstream f("pol.in");
ofstream g("pol.out");

int main()
{
    int n,m;
    f>>n>>m;
    double a[50]={0},b[50]={0},c[50]={0};
    for(int i=0;i<=n;i++)
        f>>a[i];
    for(int j=0;j<=m;j++)
        f>>b[i];
    for(int i=0;i<=n;i++)
        for(int j=0;j<=m;j++)
            c[i+j]+=a[i]*b[j];
    int p=m+n;
    g<<p<<"\n";
    for(int i=0;i<=p;i++)
        g<<c[i]<<" ";
    return 0;
}
