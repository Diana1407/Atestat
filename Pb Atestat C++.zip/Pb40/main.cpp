#include <iostream>

using namespace std;

int main()
{
    int varsta;
    int d1,d2,m1,m2,y1,y2;
    cin>>d1>>m1>>y1;
    cin>>d2>>m2>>y2;
    int ok=1;
    ///Pt. luni
    if(m1>12 || m2>12 || m1<1 || m2<1)
        ok=0;
    ///Pt. luna februarie
    if((m1==2 && d1>28) || (m2==2 && d2>28))
        ok=0;

    ///Pt. an bisect
    if(y1%400==0 || (y1%4==0 && y1%100!=0))
        if(m1==2 && d1>29)
            ok=0;
    if(y2%400==0 || (y2%4==0 && y2%100!=0))
        if(m2==2 && d2>29)
            ok=0;

    ///Pt. luni cu 31 de zile
    if(m1==1 || m1==3 || m1==5 || m1==7 || m1==8 || m1==10 || m1==12 || m2==1 || m2==3 || m2==5 || m2==7 || m2==8 || m2==10 || m2==12)
    {
        if(d1>31 || d2>31)
            ok=0;
    }

    ///Pt luni cu 30 de zile
    if(m1==4 || m1==6 || m1==9 || m1==1 || m2==4 || m2==6 || m2==9 || m2==1)
        if(d1>30 || d2>30)
            ok=0;
    if(ok==0)
        cout<<"Datile sunt invalide";
    else
    {
        varsta=y2-y1;
        if((m1==m2 && d2<d1) || m1>m2)
            varsta--;
        cout<<varsta<<" ani";
    }

    return 0;
}
