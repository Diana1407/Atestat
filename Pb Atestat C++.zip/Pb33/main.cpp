#include <iostream>
#include <fstream>

using namespace std;

ifstream f("sir.in");

int sumcif(int x)
{
    int s=0;
    while(x)
    {
        s+=x%10;
        x/=10;
    }
    return s;
}

int main()
{
    int n,a[51];
    f>>n;
    for(int i=0; i<n; i++)
        f>>a[i];
    for(int i=0;i<n/2;i++)
    {
        if(sumcif(a[i])==sumcif(a[n-i-1]))
            cout<<a[i]<<" "<<a[n-i-1]<<endl;
    }

    return 0;
}
