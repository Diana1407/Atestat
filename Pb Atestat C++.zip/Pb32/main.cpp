#include <iostream>
#include <fstream>

using namespace std;

ifstream f("numere.in");

int main()
{
    int a,b,ok=0;
    f>>b>>a;
    int x=1,y=1;
    while(x<=a)
    {
        if(x==a && y==b)
            ok=1;
        int t=x;
        x=y;
        y=y+t;
    }
    if(ok==1)
        cout<<"DA";
    else
        cout<<"NU";
    return 0;
}

///O alta metoda e cu formula si verifici daca cei doi termeni sunt nr fibonacci
///si dupa verifici daca diferenta lor e si ea termen fibonacci si totodata sa fie mai mica decat cel mai mic termen.
