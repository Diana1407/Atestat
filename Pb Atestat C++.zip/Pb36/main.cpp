#include <iostream>
#include <fstream>
#include <cstring>

using namespace std;

ifstream f("text.in");

int main()
{
    int nr=0,nrmax=-1,poz;
    char s[256];
    f.getline(s,256);
    int l=strlen(s);
    for(int i=0;i<l;i++)
    {
        if(s[i]>='0' && s[i]<='9')
            nr++;
        else
            if(nr>nrmax)
        {
            nrmax=nr;
            poz=i-nr;
        }
        nr=0;
    }
    if(nr>nrmax)
    {
        nrmax=nr;
        poz=l-1;
    }

    for(int i=poz;i<poz+nrmax;i++)
        cout<<s[i];
    return 0;
}
