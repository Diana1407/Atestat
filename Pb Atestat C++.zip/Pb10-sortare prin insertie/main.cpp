///SORTARE PRIN INSERTIE
#include <iostream>
#include <fstream>

using namespace std;

ifstream f("sort.in");
ofstream g("sort.out");

int main()
{
    int n,a[100];
    f>>n;
    for (int i=0; i<n; i++)
        f>>a[i];
    for (int i=1; i<n; i++)
        if(a[i]<a[i-1])
        {
            int aux=a[i];
            int j=i-1;
            while (aux<a[j] && j>=0)
            {
                a[j+1]=a[j];
                j--;
            }
            a[j+1]=aux;
        }
    for (int i=0; i<n; i++)
        g<<a[i]<<" ";
    return 0;

}
