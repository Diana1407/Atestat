#include <iostream>

using namespace std;

int nrdiv(int x)
{
    int d,nrd=0;
    for(d=1;d*d<x;d++)
        if(x%d==0)
            nrd+=2;
    if(d*d==x)
        nrd++;
    return nrd;
}

int main()
{
    int n,ok=1;
    cin>>n;
    int t=nrdiv(n);
    for(int i=1;i<n;i++)
        if(nrdiv(i)>=t)
    {
        ok=0;
        break;
    }
    if(ok==1)
        cout<<"DA";
    else
        cout<<"NU";
    return 0;
}
