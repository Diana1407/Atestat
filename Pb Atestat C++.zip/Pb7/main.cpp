#include <iostream>
#include <fstream>

using namespace std;

ifstream f("mult.in");
ofstream g("mult.out");

int main()
{
    int n,m,a[51],b[51],c[51],k=0;
    f>>n>>m;
    for(int i=0;i<n;i++)
        f>>a[i];
    for(int i=0;i<m;i++)
        f>>b[i];

    int i=0,j=0;
    while(i<n && j<m)
    {
        if(a[i]==b[j])
        {
            c[k++]=a[i];
            i++;
            j++;
        }
        if(a[i]<b[j])
        {
            c[k++]=a[i];
            i++;
        }
        if(a[i]>b[j])
        {
            c[k++]=b[j];
            j++;
        }
    }
    while(i<n)
    {
        c[k++]=a[i];
        i++;
    }

    while(j<m)
    {
        c[k++]=b[j];
        j++;
    }

    for(int i=0;i<k;i++)
        g<<c[i]<<" ";

    return 0;
}
