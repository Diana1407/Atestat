#include <iostream>

using namespace std;

int nrcif(int x)
{
    int nr=0;
    while(x)
    {
        x/=10;
        nr++;
    }
    if(nr%2==0)
        return 1;
    return 0;
}

int main()
{
    int n,a[101][101],nr=0;
    cin>>n;
    for(int i=0;i<n;i++)
        for(int j=0;j<n;j++)
            cin>>a[i][j];
    for(int i=1;i<n;i++)
        for(int j=0;j<i;j++)
            nr+=nrcif(a[i][j]);
    cout<<nr;
    return 0;
}
